my name is mohmed tony ,i live in egypt
YourLists: A Shopping store and Todo List Web App
A CS50 Final Project
Made as a final project for the course CS50's Introduction to Computer Science, Your store helps users manage their shopping lists as well as todo lists